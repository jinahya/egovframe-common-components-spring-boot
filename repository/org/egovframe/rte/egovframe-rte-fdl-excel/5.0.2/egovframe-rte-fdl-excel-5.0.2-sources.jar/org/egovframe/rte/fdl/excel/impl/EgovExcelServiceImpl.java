/*
 * Copyright 2008-2024 MOIS(Ministry of the Interior and Safety).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.egovframe.rte.fdl.excel.impl;

import com.ibatis.sqlmap.client.SqlMapClient;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.util.ZipSecureFile;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.egovframe.rte.fdl.cmmn.exception.BaseRuntimeException;
import org.egovframe.rte.fdl.excel.EgovExcelMapping;
import org.egovframe.rte.fdl.excel.EgovExcelService;
import org.egovframe.rte.fdl.filehandling.EgovFileUtil;
import org.egovframe.rte.fdl.string.EgovObjectUtil;
import org.mybatis.spring.SqlSessionTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.MessageSource;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * 엑셀 서비스를 처리하는 비즈니스 구현 클래스.
 * <p>
 * 개정이력(Modification Information)
 * <p>
 * 수정일		수정자				수정내용
 * ----------------------------------------------
 * 2009.06.01  윤성종				최초 생성
 * 2013.05.22  이기하				XSSF, SXSSF형식 추가(xlsx 지원)
 * 2013.05.29  한성곤				mapBeanName property 추가 및 코드 정리
 * 2014.05.14  이기하				코드 refactoring 및 mybatis 서비스 추가
 * 2017.02.15  장동한				ES-부적절한 예외 처리[CWE-253, CWE-440, CWE-754]
 * 2020.08.31  유지보수				ES-부적절한 예외 처리[CWE-253, CWE-440, CWE-754]
 * 2024.08.17  이백행				시큐어코딩 Exception 제거
 * 2026.09.10  실행환경 개발팀		xls·xlsx 자동 감지 업로드(uploadExcelAuto) 추가
 */
public class EgovExcelServiceImpl implements EgovExcelService, ApplicationContextAware {

    private static final Logger LOGGER = LoggerFactory.getLogger(EgovExcelServiceImpl.class);

    private MessageSource messageSource;
    private ApplicationContext applicationContext;
    private String mapClass;
    private String mapBeanName;
    private EgovExcelServiceDAO dao;
    private EgovExcelServiceMapper excelBatchMapper;
    private SqlMapClient sqlMapClient;
    private SqlSessionTemplate sqlSessionTemplate;

    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
        this.messageSource = (MessageSource) applicationContext.getBean("messageSource");
    }

    /**
     * MessageSource 얻기.
     */
    protected MessageSource getMessageSource() {
        return messageSource;
    }

    /**
     * ibatis 적용시 설정.
     */
    public void setSqlMapClient(SqlMapClient sqlMapClient) {
        this.sqlMapClient = sqlMapClient;
        dao = new EgovExcelServiceDAO(this.sqlMapClient);
    }

    /**
     * mybatis 적용시 설정.
     */
    public void setSqlSessionTemplate(SqlSessionTemplate sqlSessionTemplate) {
        this.sqlSessionTemplate = sqlSessionTemplate;
        excelBatchMapper = new EgovExcelServiceMapper(this.sqlSessionTemplate);
    }

    /**
     * Excel Cell과 VO를 mapping 구현 클래스.
     */
    public void setMapClass(String mapClass) {
        this.mapClass = mapClass;
    }

    /**
     * Excel Cell과 VO를 mapping 구현 Bean name (mapClass보다 우선함).
     */
    public void setMapBeanName(String mapBeanName) {
        this.mapBeanName = mapBeanName;
    }

    /**
     * Workbook 객체를 생성하여 엑셀파일을 생성한다.
     * 전달받은 Workbook을 닫지 않고 그대로 반환하며, 호출자가 이어서 사용·수정·재저장할 수 있다. 닫는 책임은 호출자에게 있다.
     */
    @Override
    public Workbook createWorkbook(Workbook wb, String filepath) {
        try {
            LOGGER.debug("EgovExcelServiceImpl.createWorkbook 1 : templatePath is {}", FilenameUtils.getFullPath(filepath));
            if (!EgovFileUtil.isExistsFile(FilenameUtils.getFullPath(filepath))) {
                LOGGER.debug("make dir {}", FilenameUtils.getFullPath(filepath));
                FileUtils.forceMkdir(new File(FilenameUtils.getFullPath(filepath)));
            }
            LOGGER.debug("EgovExcelServiceImpl.createWorkbook 2 : templatePath is {}", filepath);
            try (FileOutputStream fileOut = new FileOutputStream(filepath)) {
                LOGGER.debug("ExcelServiceImpl filepath ...");
                wb.write(fileOut);
            } finally {
                LOGGER.debug("ExcelServiceImpl loadExcelObject End ");
            }
            return wb;
        } catch (IOException e) {
            throw new BaseRuntimeException("IOException: createWorkbook", e);
        }
    }

    /**
     * 엑셀 Template를 로딩하여 엑셀파일을 생성한다.
     */
    @Override
    public Workbook loadExcelTemplate(String templateName) {
        try {
            FileInputStream fileIn = null;
            Workbook wb = null;
            LOGGER.debug("EgovExcelServiceImpl.loadExcelTemplate : templatePath is {}", templateName);
            try {
                LOGGER.debug("ExcelServiceImpl loadExcelTemplate ...");
                fileIn = new FileInputStream(templateName);
                wb = new HSSFWorkbook(fileIn);
            } finally {
                LOGGER.debug("ExcelServiceImpl loadExcelTemplate End ");
                if (fileIn != null) fileIn.close();
            }
            return wb;
        } catch (IOException e) {
            throw new BaseRuntimeException("IOException: loadExcelTemplate(String templateName)", e);
        }
    }

    /**
     * xlsx 엑셀 Template를 로딩하여 엑셀파일을 생성한다.
     */
    @Override
    public XSSFWorkbook loadExcelTemplate(String templateName, XSSFWorkbook wb) {
        try {
            FileInputStream fileIn = null;
            LOGGER.debug("EgovExcelServiceImpl.loadExcelTemplate(XSSF) : templatePath is {}", templateName);
            try {
                LOGGER.debug("ExcelServiceImpl loadExcelTemplate(XSSF) ...");
                fileIn = new FileInputStream(templateName);
                wb = new XSSFWorkbook(fileIn);
            } finally {
                LOGGER.debug("ExcelServiceImpl loadExcelTemplate(XSSF) End ");
                if (fileIn != null) fileIn.close();
            }
            return wb;
        } catch (IOException e) {
            throw new BaseRuntimeException("IOException: loadExcelTemplate(String templateName, XSSFWorkbook wb)", e);
        }
    }

    /**
     * 엑셀 파일을 로딩한다.
     */
    @Override
    public Workbook loadWorkbook(String filepath) {
        try {
            FileInputStream fileIn = null;
            Workbook wb = null;
            try {
                fileIn = new FileInputStream(filepath);
                wb = loadWorkbook(fileIn);
            } finally {
                if (fileIn != null) fileIn.close();
            }
            return wb;
        } catch (IOException e) {
            throw new BaseRuntimeException("IOException: loadWorkbook(String filepath)", e);
        }
    }

    /**
     * xlsx 엑셀 파일을 로딩한다.
     */
    @Override
    public XSSFWorkbook loadWorkbook(String filepath, XSSFWorkbook wb) {
        try {
            FileInputStream fileIn = null;
            try {
                fileIn = new FileInputStream(filepath);
                wb = loadWorkbook(fileIn, wb);
            } finally {
                if (fileIn != null) fileIn.close();
            }
            return wb;
        } catch (IOException e) {
            throw new BaseRuntimeException("IOException: loadWorkbook(String filepath, XSSFWorkbook wb)", e);
        }
    }

    /**
     * 엑셀 파일을 로딩한다.
     */
    @Override
    public Workbook loadWorkbook(InputStream fileIn) {
        try {
            POIFSFileSystem fs = null;
            Workbook wb = null;
            try {
                LOGGER.debug("ExcelServiceImpl loadWorkbook ...");
                fs = new POIFSFileSystem(fileIn);
                wb = new HSSFWorkbook(fs);
            } finally {
                if (fileIn != null) fileIn.close();
            }
            return wb;
        } catch (IOException e) {
            throw new BaseRuntimeException("Workbook loadWorkbook(InputStream fileIn)", e);
        }
    }

    /**
     * xlsx 엑셀 파일을 로딩한다.
     * POI XSSFWorkbook(InputStream)은 mark/reset 지원이 필요하므로, 미지원 시 BufferedInputStream으로 감싼다.
     */
    public XSSFWorkbook loadWorkbook(InputStream fileIn, XSSFWorkbook wb) {
        InputStream streamToUse = null;
        // 2026.02.28 KISA 보안취약점 조치
        try {
            // xlsx는 zip 포맷이라 압축률이 극단적인 zip bomb에 노출될 수 있다. POI 라이브러리 기본값
            // (minInflateRatio=0.01)에만 암묵적으로 의존하지 않고, 신뢰할 수 없는 업로드 파일을 열기
            // 직전 명시적으로 재적용해 같은 JVM의 다른 코드가 이 전역 설정을 완화했더라도 방어가
            // 유지되도록 한다.
            ZipSecureFile.setMinInflateRatio(0.01d);
            LOGGER.debug("ExcelServiceImpl loadWorkbook(XSSF) ...");
            streamToUse = (fileIn != null && fileIn.markSupported()) ? fileIn : new BufferedInputStream(fileIn);
            wb = new XSSFWorkbook(streamToUse);
            return wb;
        } catch (IOException e) {
            throw new BaseRuntimeException("XSSFWorkbook loadWorkbook(InputStream fileIn, XSSFWorkbook wb)", e);
        } finally {
            if (streamToUse != null && streamToUse != fileIn) {
                try {
                    streamToUse.close();
                } catch (IOException e) {
                    LOGGER.debug("Failed to close stream in loadWorkbook(XSSF): {}", e.getMessage());
                }
            }
        }
    }

    /**
     * 엑셀파일을 업로드하여 DB에 일괄저장한다.
     * 업로드할 엑셀의 시작 위치를 정하여 지정한 셀부터 업로드한다.
     */
    @Override
    public Integer uploadExcel(String queryId, Sheet sheet, int start, long commitCnt) {
        LOGGER.debug("sheet.getPhysicalNumberOfRows() : {}", sheet.getPhysicalNumberOfRows());

        Integer rowsAffected = 0;
        long rowCnt = sheet.getLastRowNum() + 1L;
        long cnt = (commitCnt == 0) ? rowCnt : commitCnt;

        LOGGER.debug("Runtime.getRuntime().totalMemory() : {}", Runtime.getRuntime().totalMemory());
        LOGGER.debug("Runtime.getRuntime().freeMemory() : {}", Runtime.getRuntime().freeMemory());

        long startTime = System.currentTimeMillis();
        for (int idx = start, i; idx < rowCnt; idx = i) {
            List<Object> list = new ArrayList<Object>();
            LOGGER.debug("before Runtime.getRuntime().freeMemory() : {}", Runtime.getRuntime().freeMemory());
            EgovExcelMapping mapping = null;
            if (mapBeanName != null) {
                mapping = (EgovExcelMapping) applicationContext.getBean(mapBeanName);
            } else if (mapClass != null) {
                mapping = (EgovExcelMapping) EgovObjectUtil.instantiate(mapClass);
            } else {
                throw new RuntimeException(getMessageSource().getMessage("error.excel.property.error", null, Locale.getDefault()));
            }

            for (i = idx; i < rowCnt && i < (cnt + idx); i++) {
                Row row = sheet.getRow(i);
                if (row == null) {
                    LOGGER.debug("row {} is blank, skipped", i);
                    continue;
                }
                list.add(mapping.mappingColumn(row));
            }
            if (sqlSessionTemplate == null && sqlMapClient == null) {
                throw new RuntimeException(getMessageSource().getMessage("error.excel.persistence.error", null, Locale.getDefault()));
            }
            if (!list.isEmpty()) {
                if (sqlSessionTemplate != null) {
                    rowsAffected += excelBatchMapper.batchInsert(queryId, list);
                } else {
                    rowsAffected += dao.batchInsert(queryId, list);
                }
            }

            LOGGER.debug("after Runtime.getRuntime().freeMemory() : {}", Runtime.getRuntime().freeMemory());
            LOGGER.debug("rowsAffected : {}", rowsAffected);
        }

        LOGGER.debug("batchInsert time is {}", (System.currentTimeMillis() - startTime));
        LOGGER.debug("uploadExcel result count is {}", rowsAffected);

        return rowsAffected;
    }

    /**
     * 엑셀 파일을 xls·xlsx 자동 감지로 로딩해 첫 번째 시트를 DB 에 일괄 저장한다.
     * 형식은 확장자가 아닌 내용으로 감지하며, 워크북은 저장이 끝나면 닫는다.
     */
    @Override
    public Integer uploadExcelAuto(String queryId, InputStream fileIn, int start, long commitCnt) {
        if (fileIn == null) {
            throw new IllegalArgumentException("fileIn must not be null");
        }
        // xlsx 는 zip 형식이라 zip bomb 방어 비율을 열기 직전에 POI 기본값으로 복원한다(loadWorkbook(InputStream, XSSFWorkbook) 과 동일).
        ZipSecureFile.setMinInflateRatio(0.01d);
        try (Workbook wb = WorkbookFactory.create(fileIn)) {
            return uploadExcel(queryId, wb.getSheetAt(0), start, commitCnt);
        } catch (IOException e) {
            throw new BaseRuntimeException("Failed to open workbook for upload (xls/xlsx auto-detect)", e);
        }
    }

    /**
     * 엑셀파일을 읽어서 DB upload 한다.
     */
    @Override
    public Integer uploadExcel(String queryId, InputStream fileIn, int start, long commitCnt) {
        Workbook wb = loadWorkbook(fileIn);
        Sheet sheet = wb.getSheetAt(0);
        return uploadExcel(queryId, sheet, start, commitCnt);
    }

    /**
     * xlsx 엑셀파일을 읽어서 DB upload 한다.
     */
    @Override
    public Integer uploadExcel(String queryId, InputStream fileIn, int start, long commitCnt, XSSFWorkbook wb) {
        wb = loadWorkbook(fileIn, wb);
        Sheet sheet = wb.getSheetAt(0);
        return uploadExcel(queryId, sheet, start, commitCnt);
    }

    /**
     * 엑셀파일을 저장한다.
     */
    @Override
    public Integer uploadExcel(String queryId, InputStream fileIn) {
        return uploadExcel(queryId, fileIn, 0, 0);
    }

    /**
     * xlsx 엑셀파일을 저장한다.
     */
    @Override
    public Integer uploadExcel(String queryId, InputStream fileIn, XSSFWorkbook type) {
        return uploadExcel(queryId, fileIn, 0, 0, type);
    }

    /**
     * 엑셀파일을 업로드하여 DB에 일괄저장한다.
     * 업로드할 엑셀의 시작 위치를 정하여 지정한 셀부터 업로드한다.
     */
    @Override
    public Integer uploadExcel(String queryId, InputStream fileIn, short sheetIndex, int start, long commitCnt) {
        Workbook wb = loadWorkbook(fileIn);
        Sheet sheet = wb.getSheetAt(sheetIndex);
        return uploadExcel(queryId, sheet, start, commitCnt);
    }

    /**
     * xlsx 엑셀파일을 업로드하여 DB에 일괄저장한다.
     * 업로드할 엑셀의 시작 위치를 정하여 지정한 셀부터 업로드한다.
     */
    @Override
    public Integer uploadExcel(String queryId, InputStream fileIn, short sheetIndex, int start, long commitCnt, XSSFWorkbook wb) {
        wb = loadWorkbook(fileIn, wb);
        Sheet sheet = wb.getSheetAt(sheetIndex);
        return uploadExcel(queryId, sheet, start, commitCnt);
    }

    /**
     * 엑셀파일을 업로드하여 DB에 일괄저장한다.
     * 업로드할 엑셀의 시작 위치를 정하여 지정한 셀부터 업로드한다.
     */
    @Override
    public Integer uploadExcel(String queryId, InputStream fileIn, String sheetName, int start, long commitCnt) {
        Workbook wb = loadWorkbook(fileIn);
        Sheet sheet = wb.getSheet(sheetName);
        return uploadExcel(queryId, sheet, start, commitCnt);
    }

    /**
     * xlsx 엑셀파일을 업로드하여 DB에 일괄저장한다.
     * 업로드할 엑셀의 시작 위치를 정하여 지정한 셀부터 업로드한다.
     */
    @Override
    public Integer uploadExcel(String queryId, InputStream fileIn, String sheetName, int start, long commitCnt, XSSFWorkbook wb) {
        wb = loadWorkbook(fileIn, wb);
        Sheet sheet = wb.getSheet(sheetName);
        return uploadExcel(queryId, sheet, start, commitCnt);
    }

}
