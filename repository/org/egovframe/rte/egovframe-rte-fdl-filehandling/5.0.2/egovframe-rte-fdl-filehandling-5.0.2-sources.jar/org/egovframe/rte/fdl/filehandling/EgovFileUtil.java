/*
 * Copyright 2008-2024 MOIS(Ministry of the Interior and Safety).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.egovframe.rte.fdl.filehandling;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.vfs2.*;
import org.egovframe.rte.fdl.logging.util.EgovResourceReleaser;
import org.egovframe.rte.fdl.string.EgovStringUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.io.FileNotFoundException;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.util.*;
import java.util.regex.Pattern;

/**
 * 파일 서비스를 제공하기 위해 구현한 클래스이다.
 *
 * <p>로컬 파일 처리에는 기준 경로를 인자로 받고 실패를 예외로 알리는 {@code EgovFiles} 를 권장한다.
 * 이 클래스는 Commons VFS 가 필요한 경우와 기존 코드 호환을 위해 유지한다. {@code rm}/{@code cp}/{@code mv} 는
 * 실패를 예외로 던지지 않는 기존 계약을 지키되, 실패가 묻히지 않도록 WARN 로그를 남긴다.</p>
 * <p>
 * 수정일		수정자				수정내용
 * ----------------------------------------------
 * 2009.06.01	윤성종				최초 생성
 * 2014.05.14	이기하				vfs -> vfs2로 패키지 변경
 * 2017.02.28	장동한				시큐어코딩(ES)-Null Pointer 역참조[CWE-476]
 * 2017.02.28	장동한				시큐어코딩(ES)-부적절한 자원 해제[CWE-404]
 * 2026.09.10	실행환경 개발팀		VFS 초기화 실패를 WARN 과 명시 예외로 보고, rm/cp/mv 실패 WARN, cd/pwd/grep/ls deprecated
 */
public class EgovFileUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(EgovFileUtil.class);
    private static final int BUFFER_SIZE = 1024;
    private static FileObject basefile;
    private static FileSystemManager manager;

    static {
        try {
            manager = VFS.getManager();
            basefile = manager.resolveFile(System.getProperty("user.dir"));
        } catch (FileSystemException e) {
            // debug 로 삼키면 이후 모든 호출이 원인을 알 수 없는 NullPointerException 이 된다.
            // 사용 시점에는 manager()/basefile() 가드가 원인을 담은 IllegalStateException 을 던진다.
            LOGGER.warn("EgovFileUtil VFS initialization failed - subsequent calls will fail: {}", e.getMessage());
        }
    }

    /**
     * VFS 초기화 실패 시 원인을 알 수 없는 NullPointerException 대신 명확한 예외를 던지기 위한 가드
     */
    private static FileSystemManager manager() {
        if (manager == null) {
            throw new IllegalStateException(
                    "Commons VFS is not initialized (see startup WARN log).");
        }
        return manager;
    }

    private static FileObject basefile() {
        if (basefile == null) {
            throw new IllegalStateException(
                    "Commons VFS base directory is not initialized (see startup WARN log).");
        }
        return basefile;
    }

    /**
     * 지정한 위치의 파일 및 디렉토리를 삭제한다.
     *
     * <p>삭제 범위는 자신과 직계 자식까지({@code SELECT_SELF_AND_CHILDREN})이며, 실패하면 예외 없이 -1 을 돌려주고
     * WARN 로그를 남긴다. 깊이 제한 없는 삭제와 실패 전파가 필요하면 {@code EgovFiles.deleteRecursively(java.nio.file.Path)} 를 사용한다.</p>
     */
    public static int rm(final String cmd) {
        int result = -1;
        try {
            final FileObject file = manager().resolveFile(basefile(), cmd);
            result = file.delete(Selectors.SELECT_SELF_AND_CHILDREN);
        } catch (FileSystemException e) {
            LOGGER.warn("EgovFileUtil.rm failed for [{}]: {}", cmd, e.getMessage());
        }
        return result;
    }

    /**
     * 지정한 위치의 파일을 대상 위치로 복사한다.
     *
     * <p>실패하면 예외 없이 돌아오고 WARN 로그만 남긴다(기존 계약). 실패를 예외로 받으려면
     * {@code EgovFiles.copy(java.nio.file.Path, java.nio.file.Path)} 를 사용한다.</p>
     */
    public static void cp(String source, String target) {
        try {
            final FileObject src = manager().resolveFile(basefile(), source);
            FileObject dest = manager().resolveFile(basefile(), target);
            if (dest.exists() && dest.getType() == FileType.FOLDER) {
                dest = dest.resolveFile(src.getName().getBaseName());
            }
            dest.copyFrom(src, Selectors.SELECT_ALL);
        } catch (FileSystemException e) {
            LOGGER.warn("EgovFileUtil.cp failed [{}] -> [{}]: {}", source, target, e.getMessage());
        }
    }

    /**
     * 지정한 위치의 파일을 대상 위치로 이동한다.
     *
     * <p>실패하면 예외 없이 돌아오고 WARN 로그만 남긴다(기존 계약). 실패를 예외로 받으려면
     * {@code EgovFiles.move(java.nio.file.Path, java.nio.file.Path)} 를 사용한다.</p>
     */
    public static void mv(String source, String target) {
        try {
            final FileObject src = manager().resolveFile(basefile(), source);
            FileObject dest = manager().resolveFile(basefile(), target);
            if (dest.exists() && dest.getType() == FileType.FOLDER) {
                dest = dest.resolveFile(src.getName().getBaseName());
            }
            src.moveTo(dest);
        } catch (FileSystemException e) {
            LOGGER.warn("EgovFileUtil.mv failed [{}] -> [{}]: {}", source, target, e.getMessage());
        }
    }

    /**
     * 현재 작업위치를 리턴한다.
     *
     * @deprecated {@link #cd(String)} 가 바꾸는 프로세스 전역 기준 경로를 읽는 API 라 동시 요청 환경에서 안전하지 않다.
     * 기준 경로를 인자로 받는 {@code EgovFiles} 를 사용한다.
     */
    @Deprecated
    public static FileName pwd() {
        return basefile().getName();
    }

    /**
     * 파일의 일시를 현재 일시로 변경한다.
     */
    public static long touch(final String filepath) throws FileSystemException {
        long currentTime = 0;
        final FileObject file = manager().resolveFile(basefile(), filepath);
        if (!file.exists()) {
            file.createFile();
        }
        currentTime = System.currentTimeMillis();
        file.getContent().setLastModifiedTime(currentTime);
        return currentTime;
    }

    /**
     * 현재 작업공간의 위치를 지정한 위치로 이동한다.
     *
     * @deprecated 프로세스 전역 static 기준 경로를 바꾸므로, 한 요청의 호출이 다른 모든 스레드의
     * {@code rm}/{@code cp}/{@code mv}/{@code touch} 상대 경로 해석 기준을 바꾼다. 기준 경로를 항상 인자로 받는
     * {@code EgovFiles} 를 사용한다.
     */
    @Deprecated
    public static void cd(final String changDirectory) throws FileSystemException {
        final String path;
        if (!EgovStringUtil.isNull(changDirectory)) {
            path = changDirectory;
        } else {
            path = System.getProperty("user.home");
        }

        FileObject tmp = manager().resolveFile(basefile(), path);
        if (tmp.exists()) {
            basefile = tmp;
        } else {
            LOGGER.debug("### EogvFileUtil cd() Folder does not exist: {}", tmp.getName());
        }
        LOGGER.debug("### EogvFileUtil cd() Current folder is {}", basefile.getName());
    }

    /**
     * 파일을 플랫폼 기본 문자셋({@link Charset#defaultCharset()})으로 읽는다.
     * 인코딩을 지정하려면 {@link #readFile(File, String)}을 사용한다.
     */
    public static String readFile(File file) throws IOException {
        String sResult = "";

        try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(file))) {
            sResult = readFileContent(in);
        } catch (IllegalArgumentException e) {
            LOGGER.debug("[{}] EogvFileUtil : {}", e.getClass().getName(), e.getMessage());
        }

        return sResult;
    }

    /**
     * String 형으로 스트림 전체를 읽어 플랫폼 기본 문자셋으로 디코딩한다.
     */
    public static String readFileContent(InputStream in) throws IOException {
        return new String(in.readAllBytes(), Charset.defaultCharset());
    }

    /**
     * String 형으로 파일 전체를 읽어 지정한 인코딩으로 디코딩한다. 원본의 개행은 그대로 보존된다.
     * encoding이 null이면 플랫폼 기본 문자셋을 사용한다.
     */
    public static String readFile(File file, String encoding) throws IOException {
        Charset charset = encoding == null ? Charset.defaultCharset() : Charset.forName(encoding);
        try (InputStream in = new FileInputStream(file)) {
            return new String(in.readAllBytes(), charset);
        }
    }

    /**
     * 텍스트 라인을 읽는다. UTF-8 지정 시 잘못된 바이트 시퀀스는 대체 문자로 처리한다.
     */
    private static List<String> readTextLines(File file, String encoding) throws IOException {
        if (encoding != null && ("UTF-8".equalsIgnoreCase(encoding) || "UTF8".equalsIgnoreCase(encoding))) {
            return readUtf8LinesLenient(file);
        }
        return FileUtils.readLines(file, encoding);
    }

    private static List<String> readUtf8LinesLenient(File file) throws IOException {
        List<String> lines = new ArrayList<>();
        CharsetDecoder decoder = StandardCharsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPLACE)
                .onUnmappableCharacter(CodingErrorAction.REPLACE);
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(new FileInputStream(file), decoder))) {
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }
        }
        return lines;
    }

    /**
     * 텍스트 내용을 파일로 쓴다.
     */
    public static void writeFile(File file, String text) {
        try (FileWriter writer = new FileWriter(file)) {
            writer.write(text);
        } catch (IOException e) {
            LOGGER.debug("[{}] EogvFileUtil : {}", e.getClass().getName(), e.getMessage());
        }
    }

    /**
     * 텍스트 내용을 지정한 인코딩으로 파일에 쓴다.
     * <p>호출자가 이미 만든 {@link File}을 받으므로(신뢰 여부는 호출자 책임), 상대/절대 경로 제한이
     * 적용되는 {@link #writeFile(String, String, String)}과 달리 절대 경로도 그대로 허용한다.</p>
     */
    public static void writeFile(File file, String data, String encoding) throws IOException {
        FileUtils.writeStringToFile(file, data, encoding);
    }

    /**
     * 텍스트 내용을 파일로 쓴다.
     * <p>fileName은 상대 경로만 허용한다(신뢰할 수 없는 입력에도 안전하게 사용하기 위함).
     * 신뢰할 수 있는 절대 경로에 써야 한다면 {@link #writeFile(File, String)}을 직접 사용하라.</p>
     */
    public static void writeFile(String fileName, String text) {
        assertNoPathTraversal(fileName);
        writeFile(new File(fileName), text);
    }

    /**
     * 텍스트 내용을 지정한 인코딩으로 파일에 쓴다.
     * <p>fileName은 상대 경로만 허용한다(신뢰할 수 없는 입력에도 안전하게 사용하기 위함).
     * 신뢰할 수 있는 절대 경로에 써야 한다면 {@link #writeFile(File, String, String)}을 직접 사용하라.</p>
     */
    public static void writeFile(String fileName, String data, String encoding) throws IOException {
        assertNoPathTraversal(fileName);
        FileUtils.writeStringToFile(new File(fileName), data, encoding);
    }

    /**
     * 호출자가 지정한 파일 경로가 상위 디렉토리 이동 시퀀스("..")를 포함하거나 절대 경로여서
     * 의도한 위치를 벗어난 경로 순회(Path Traversal)나 임의 파일 쓰기/읽기로 이어지지 않도록 차단한다.
     * 신뢰할 수 없는 입력(사용자 업로드 파일명 등)은 항상 이 검증을 통과하는 상대 경로여야 한다.
     */
    private static void assertNoPathTraversal(String fileName) {
        if (fileName == null || fileName.isEmpty()) {
            throw new IllegalArgumentException("Invalid file path: path must not be null or empty.");
        }
        if (fileName.indexOf('\0') >= 0) {
            throw new IllegalArgumentException("Invalid file path: null byte is not allowed.");
        }
        if (fileName.contains("..")) {
            throw new IllegalArgumentException("Invalid file path: path traversal sequence('..') is not allowed.");
        }
        if (new File(fileName).isAbsolute()) {
            throw new IllegalArgumentException("Invalid file path: absolute path is not allowed.");
        }
    }

    /**
     * byte형으로 파일의 내용을 읽어온다.
     */
    public static byte[] getContent(final FileObject file) throws IOException {
        final FileContent content = file.getContent();
        final int size = (int) content.getSize();
        final byte[] buf = new byte[size];
        final InputStream in = content.getInputStream();

        try {
            int read = 0;
            for (int pos = 0; pos < size && read >= 0; pos += read) {
                read = in.read(buf, pos, size - pos);
            }
        } finally {
            EgovResourceReleaser.close(in);
        }

        return buf;
    }

    /**
     * 내용을 파일에 OutputStream 으로 저장한다.
     */
    public static void writeContent(final FileObject file, final OutputStream outstr) throws IOException {
        final InputStream instr = file.getContent().getInputStream();
        try {
            final byte[] buffer = new byte[BUFFER_SIZE];
            while (true) {
                final int nread = instr.read(buffer);
                if (nread < 0) {
                    break;
                }
                outstr.write(buffer, 0, nread);
            }
        } finally {
            EgovResourceReleaser.close(instr);
        }
    }

    /**
     * 파일 객체를 대상 파일객체로 복사한다.
     */
    public static void copyContent(final FileObject srcFile, final FileObject destFile) throws IOException {
        final OutputStream outstr = destFile.getContent().getOutputStream();
        try {
            writeContent(srcFile, outstr);
        } finally {
            EgovResourceReleaser.close(outstr);
        }
    }

    /**
     * 파일의 확장자를 가져온다.
     */
    public static String getFileExtension(String filename) {
        return FilenameUtils.getExtension(filename);
    }

    /**
     * 파일의 존재여부를 확인한다.
     */
    public static boolean isExistsFile(String filename) {
        File file = new File(filename);
        return file.exists();
    }

    /**
     * 디렉토리명을 제외한 파일명을 가져온다.
     */
    public static String stripFilename(String filename) {
        return FilenameUtils.getBaseName(filename);
    }

    /**
     * 저정한 파일을 삭제한다.
     */
    public static void delete(File file) throws IOException {
        //2017.02.28 장동한 시큐어코딩(ES)-Null Pointer 역참조[CWE-476]
        if (file != null) {
            if (file.isDirectory()) {
                File[] children = file.listFiles();
                for (int i = 0; i < Objects.requireNonNull(children).length; i++) {
                    delete(children[i]);
                }
            }

            if (!file.delete()) {
                throw new IOException("Unable to delete " + file.getPath());
            }
        }
    }

    /**
     * 텍스트 파일을 읽어온다.
     * <p>fileName은 상대 경로만 허용한다({@link #assertNoPathTraversal(String)} 참고).</p>
     */
    public static StringBuffer readTextFile(String fileName, boolean newline) throws IOException {
        assertNoPathTraversal(fileName);
        File file = new File(fileName);
        if (!file.exists()) {
            throw new FileNotFoundException();
        }

        StringBuffer buf = new StringBuffer();
        try (BufferedReader in = new BufferedReader(new FileReader(file))) {
            String str;
            while ((str = in.readLine()) != null) {
                buf.append(str);
                if (newline) {
                    buf.append(System.lineSeparator());
                }
            }
        }

        return buf;
    }

    /**
     * 특정위치의 파일 객체를 가져온다.
     */
    public static FileObject getFileObject(final String filepath) throws FileSystemException {
        FileSystemManager mgr = VFS.getManager();
        return mgr.resolveFile(mgr.resolveFile(System.getProperty("user.dir")), filepath);
    }

    /**
     * 특정 패턴이 존재하는 파일을 검색한다.
     *
     * @deprecated 이름과 달리 패턴에 맞는 줄이 아니라 <b>패턴을 기준으로 나눈 조각</b>을 돌려준다. 기존 호출 호환을 위해
     * 동작은 그대로 두며, 패턴에 맞는 줄이 필요하면 {@code EgovFiles.grepLines(java.nio.file.Path, String)} 를 사용한다.
     */
    @Deprecated
    public static List<String> grep(final Object[] search, final String pattern) {
        Pattern searchPattern = Pattern.compile(pattern);
        String[] strings = searchPattern.split(Arrays.toString(search));
        return new ArrayList<>(Arrays.asList(strings));
    }

    /**
     * 특정 패턴이 존재하는 파일을 검색한다.
     *
     * @deprecated 이름과 달리 패턴에 맞는 줄이 아니라 <b>패턴을 기준으로 나눈 조각</b>을 돌려준다. 기존 호출 호환을 위해
     * 동작은 그대로 두며, 패턴에 맞는 줄이 필요하면 {@code EgovFiles.grepLines(java.nio.file.Path, String)} 를 사용한다.
     */
    @Deprecated
    public static List<String> grep(final File file, final String pattern) throws IOException {
        Pattern searchPattern = Pattern.compile(pattern);
        List<String> lists = readTextLines(file, "UTF-8");
        Object[] search = lists.toArray();
        String[] strings = searchPattern.split(Arrays.toString(search));
        List<String> list = new ArrayList<>();
        Collections.addAll(list, strings);
        return list;
    }

    /**
     * 시스템 임시 디렉토리를 얻어온다.
     */
    public static String getTmpDirectory() throws IOException {
        File baseDir = new File(System.getProperty("java.io.tmpdir"));
        return baseDir.getCanonicalPath();
    }

    /**
     * 지정한 위치의 파일목록을 조회한다.
     *
     * @deprecated 목록을 채우지 않고 <b>항상 빈 리스트</b>를 돌려주며 debug 로그만 남긴다. 기존 호출 호환을 위해 동작은
     * 그대로 두며, 실제 목록이 필요하면 {@code EgovFiles.list(java.nio.file.Path)} 나 {@code EgovFiles.listRecursively(java.nio.file.Path)} 를 사용한다.
     */
    @Deprecated
    public List<?> ls(final String[] cmd) throws FileSystemException {
        List<Object> list = new ArrayList<Object>();
        int pos = 1;
        final boolean recursive;
        if (cmd.length > pos && cmd[pos].equals("-R")) {
            recursive = true;
            pos++;
        } else {
            recursive = false;
        }

        final FileObject file;
        if (cmd.length > pos) {
            file = manager().resolveFile(basefile(), cmd[pos]);
        } else {
            file = basefile();
        }

        if (file.getType() == FileType.FOLDER) {
            LOGGER.debug("### EogvFileUtil ls() Contents of {}", file.getName());
            LOGGER.debug("### EogvFileUtil ls() info : {}", listChildren(file, recursive, ""));
        } else {
            LOGGER.debug("### EogvFileUtil ls() info : {}", file.getName());
            final FileContent content = file.getContent();
            LOGGER.debug("### EogvFileUtil ls() Size : {}bytes.", content.getSize());
            final DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.MEDIUM);
            final String lastMod = dateFormat.format(new Date(content.getLastModifiedTime()));
            LOGGER.debug("### EogvFileUtil ls() Last modified : {}", lastMod);
        }

        return list;
    }

    /**
     * 지정한 위치의 하위 디렉토리 목록을 가져온다.
     */
    private StringBuilder listChildren(final FileObject dir, final boolean recursive, final String prefix) throws FileSystemException {
        StringBuilder line = new StringBuilder();
        final FileObject[] children = dir.getChildren();

        for (final FileObject child : children) {
            line.append(prefix).append(child.getName().getBaseName());
            if (child.getType() == FileType.FOLDER) {
                line.append("/");
                if (recursive) {
                    line.append(listChildren(child, recursive, prefix + "    "));
                }
            }
        }

        return line;
    }

}
