/*
 * Copyright 2008-2024 MOIS(Ministry of the Interior and Safety).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.egovframe.rte.bat.core.item.database;

import org.egovframe.rte.bat.core.item.database.support.EgovItemPreparedStatementSetter;
import org.egovframe.rte.bat.core.reflection.EgovReflectionSupport;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.util.Assert;

import javax.sql.DataSource;
import java.lang.reflect.Method;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * EgovJdbcBatchItemWriter EgovItemPreparedStatementSetter인터페이스를 상속받은
 * ItemPreparedStatementSetter이 설정되어 있어야 함.
 *
 * @author 배치실행개발팀
 * @version 1.0
 * <pre>
 * 개정이력(Modification Information)
 *
 * 수정일		수정자				수정내용
 * ----------------------------------------------
 * 2012.07.20	배치실행개발팀		최초 생성
 * 2017.02.14	장동한				시큐어코딩(ES)-부적절한 예외 처리[CWE-253, CWE-440, CWE-754]
 * </pre>
 * @since 2012.07.20
 */
public class EgovJdbcBatchItemWriter<T> implements ItemWriter<T>, InitializingBean {

    // SimpleJdbcOperations
    private JdbcOperations jdbcTemplate;

    // EgovItemPreparedStatementSetter
    private EgovItemPreparedStatementSetter<T> itemPreparedStatementSetter;

    // sql 쿼리
    private String sql;

    // params 초기화
    private String[] params = new String[0];

    // assertUpdates 초기화
    private boolean assertUpdates = true;

    // usingParameters
    private boolean usingParameters;

    private EgovReflectionSupport<T> reflector;

    // params 가 고정이고 item 이 동질이면 sqlTypes 산출(getDeclaredField reflection)을 청크마다 반복할 필요가 없다.
    // 최초 1회 산출 후 캐시하고, item 클래스가 달라지면(이질 item) 재산출하여 정확성을 보장한다.
    // 멀티스레드 Step 에서 torn-read(이질 클래스 동시 청크 시 itemClass 와 sqlTypes 가 어긋나는 창)를
    // 막기 위해 클래스+타입배열을 불변 holder 로 묶어 단일 volatile 참조로 원자 발행하고, 소비는 지역변수로 한다.
    private volatile SqlTypeCache sqlTypeCache;

    /**
     * sqlTypes 캐시용 불변 holder. itemClass 와 sqlTypes 가 항상 한 쌍으로 발행된다.
     */
    private static final class SqlTypeCache {
        private final Class<?> itemClass;
        private final String[] sqlTypes;

        private SqlTypeCache(Class<?> itemClass, String[] sqlTypes) {
            this.itemClass = itemClass;
            this.sqlTypes = sqlTypes;
        }
    }

    /**
     * AssertUpdates 설정 셋팅
     */
    public void setAssertUpdates(boolean assertUpdates) {
        this.assertUpdates = assertUpdates;
    }

    /**
     * sql 셋팅
     */
    public void setSql(String sql) {
        this.sql = sql;
    }

    /**
     * ItemPreparedStatementSetter 셋팅
     */
    public void setItemPreparedStatementSetter(EgovItemPreparedStatementSetter<T> preparedStatementSetter) {
        this.itemPreparedStatementSetter = preparedStatementSetter;
    }

    /**
     * params 셋팅
     */
    public void setParams(String[] params) {
        this.params = params == null ? null : Arrays.asList(params).toArray(new String[params.length]);
        // params 가 바뀌면 기존 sqlTypes 캐시는 stale 이므로 무효화한다.
        this.sqlTypeCache = null;
    }

    /**
     * dataSource 셋팅
     */
    public void setDataSource(DataSource dataSource) {
        if (jdbcTemplate == null) {
            this.jdbcTemplate = new JdbcTemplate(dataSource);
        }
    }

    /**
     * SimpleJdbcTemplate 셋팅
     */
    public void setSimpleJdbcTemplate(JdbcOperations jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * 설정의 properties 셋팅확인
     */
    public void afterPropertiesSet() {
        Assert.notNull(jdbcTemplate, "A DataSource or a SimpleJdbcTemplate is required.");
        Assert.notNull(sql, "An SQL statement is required.");

        if (params.length != 0) {
            usingParameters = true;
        }

        Assert.notNull(itemPreparedStatementSetter, "Using SQL statement with '?' placeholders requires an EgovMethodMapItemPreparedStatementSetter");

        reflector = new EgovReflectionSupport<T>();
    }

    /**
     * DB Write 를 위해 적절한 setValues 호출
     * setValues(item, ps, params, sqlTypes, methodMap) :
     * setValues(item, ps) : 따로 VO
     */
    @Override
    public void write(Chunk<? extends T> chunk) throws Exception {
        List<? extends T> items = chunk.getItems();
        if (!items.isEmpty()) {
            int[] updateCounts = jdbcTemplate.execute(sql, new PreparedStatementCallback<int[]>() {
                @Override
                public int[] doInPreparedStatement(PreparedStatement ps) throws SQLException, DataAccessException {
                    // Parameters 가 있으면 item, ps, params, sqlTypes,methodMap 를 파라메터로 받는 setValues call
                    // 없으면 item, ps 를 파라메터로 받는 setValues call
                    if (usingParameters) {
                        T firstItem = items.get(0);
                        Class<?> itemClass = firstItem.getClass();
                        SqlTypeCache local = sqlTypeCache;     // volatile read 1회
                        if (local == null || !itemClass.equals(local.itemClass)) {
                            local = new SqlTypeCache(itemClass, reflector.getSqlTypeArray(params, firstItem));
                            sqlTypeCache = local;              // volatile publish (원자 발행)
                        }
                        String[] sqlTypes = local.sqlTypes;    // 지역 소비, 공유필드 재독해 금지
                        reflector.generateGetterMethodMap(params, firstItem);
                        Map<String, Method> methodMap = reflector.getMethodMap();

                        for (T item : items) {
                            itemPreparedStatementSetter.setValues(item, ps, params, sqlTypes, methodMap);
                            ps.addBatch();
                        }
                    } else {
                        for (T item : items) {
                            itemPreparedStatementSetter.setValues(item, ps);
                            ps.addBatch();
                        }
                    }
                    return ps.executeBatch();
                }
            });

            if (assertUpdates && updateCounts != null) {
                for (int i = 0; i < updateCounts.length; i++) {
                    if (updateCounts[i] == 0) {
                        throw new EmptyResultDataAccessException("Item " + i + " of " + updateCounts.length + " did not update any rows: [" + items.get(i) + "]", 1);
                    }
                }
            }
        }
    }
}
