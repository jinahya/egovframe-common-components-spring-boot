/*
 * Copyright 2008-2024 MOIS(Ministry of the Interior and Safety).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.egovframe.rte.itl.webservice;

import jakarta.xml.ws.Endpoint;
import org.apache.cxf.Bus;
import org.apache.cxf.BusFactory;
import org.egovframe.rte.itl.integration.EgovIntegrationContext;
import org.egovframe.rte.itl.integration.EgovIntegrationNoSuchServiceException;
import org.egovframe.rte.itl.integration.EgovIntegrationService;
import org.egovframe.rte.itl.integration.EgovIntegrationServiceProvider;
import org.egovframe.rte.itl.integration.metadata.IntegrationDefinition;
import org.egovframe.rte.itl.integration.metadata.dao.IntegrationDefinitionDao;
import org.egovframe.rte.itl.integration.monitor.EgovIntegrationServiceMonitor;
import org.egovframe.rte.itl.integration.type.CircularInheritanceException;
import org.egovframe.rte.itl.integration.type.NoSuchTypeException;
import org.egovframe.rte.itl.integration.type.RecordType;
import org.egovframe.rte.itl.integration.type.TypeLoader;
import org.egovframe.rte.itl.webservice.data.WebServiceClientDefinition;
import org.egovframe.rte.itl.webservice.data.WebServiceServerDefinition;
import org.egovframe.rte.itl.webservice.data.dao.WebServiceClientDefinitionDao;
import org.egovframe.rte.itl.webservice.data.dao.WebServiceServerDefinitionDao;
import org.egovframe.rte.itl.webservice.service.*;
import org.egovframe.rte.itl.webservice.service.impl.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.util.StringUtils;

import java.lang.reflect.Field;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 전자정부 웹서비스 Context 구현 클래스
 * <p>
 * <b>NOTE:</b> 전자정부 웹서비스 Context Class이다. </p>
 *
 * @author 실행환경 개발팀 심상호
 * @version 1.0
 * <pre>
 * 개정이력(Modification Information)
 *
 * 수정일		수정자				수정내용
 * ----------------------------------------------
 * 2009.06.01	심상호				최초 생성
 * 2017.02.15	장동한				시큐어코딩(ES)-부적절한 예외 처리[CWE-253, CWE-440, CWE-754]
 * </pre>
 * @since 2009.06.01
 */
public class EgovWebServiceContext implements EgovIntegrationContext, ApplicationContextAware {

    private static final Logger LOGGER = LoggerFactory.getLogger(EgovWebServiceContext.class);

    /**
     * 기관 Id
     */
    protected String organizationId;

    /**
     * 시스템 Id
     */
    protected String systemId;

    /**
     * Default Timeout (millisecond)
     */
    protected long defaultTimeout;

    /**
     * 연계 정의 DAO
     */
    protected IntegrationDefinitionDao integrationDefinitionDao;

    /**
     * 웹서비스 클라이언트 정의 DAO
     */
    protected WebServiceClientDefinitionDao webServiceClientDefinitionDao;

    /**
     * 웹서비스 서버 정의 DAO
     */
    protected WebServiceServerDefinitionDao webServiceServerDefinitionDao;

    /**
     * Type Loader
     */
    protected TypeLoader typeLoader;

    /**
     * ClassLoader
     */
    protected EgovWebServiceClassLoader classLoader;

    /**
     * ApplicationContext
     */
    protected ApplicationContext applicationContext;

    /**
     * MessageConverter
     */
    protected MessageConverter messageConverter;

    /**
     * ServiceMap
     */
    protected Map<String, EgovWebService> serviceMap;

    /**
     * ServerList
     */
    protected List<ServerInfo> serverList;

    /**
     * Bus
     */
    protected Bus bus;

    /**
     * Default Constructor
     */
    public EgovWebServiceContext() {
        super();
    }

    /**
     * organizationId
     *
     * @param organizationId the organizationId to set
     */
    public void setOrganizationId(String organizationId) {
        this.organizationId = organizationId;
    }

    /**
     * systemId
     *
     * @param systemId the systemId to set
     */
    public void setSystemId(String systemId) {
        this.systemId = systemId;
    }

    /**
     * defaultTimeout
     *
     * @return the defaultTimeout
     */
    public long getDefaultTimeout() {
        return defaultTimeout;
    }

    /**
     * defaultTimeout
     *
     * @param defaultTimeout the defaultTimeout to set
     */
    public void setDefaultTimeout(long defaultTimeout) {
        this.defaultTimeout = defaultTimeout;
    }

    /**
     * integrationDefinitionDao
     *
     * @param integrationDefinitionDao the integrationDefinitionDao to set
     */
    public void setIntegrationDefinitionDao(IntegrationDefinitionDao integrationDefinitionDao) {
        this.integrationDefinitionDao = integrationDefinitionDao;
    }

    /**
     * webServiceClientDefinitionDao
     *
     * @param webServiceClientDefinitionDao the webServiceClientDefinitionDao to set
     */
    public void setWebServiceClientDefinitionDao(WebServiceClientDefinitionDao webServiceClientDefinitionDao) {
        this.webServiceClientDefinitionDao = webServiceClientDefinitionDao;
    }

    /**
     * webServiceServerDefinitionDao
     *
     * @param webServiceServerDefinitionDao the webServiceServerDefinitionDao to set
     */
    public void setWebServiceServerDefinitionDao(WebServiceServerDefinitionDao webServiceServerDefinitionDao) {
        this.webServiceServerDefinitionDao = webServiceServerDefinitionDao;
    }

    /**
     * typeLoader
     *
     * @param typeLoader the typeLoader to set
     */
    public void setTypeLoader(TypeLoader typeLoader) {
        this.typeLoader = typeLoader;
    }

    /**
     * classLoader
     *
     * @param classLoader the classLoader to set
     */
    public void setClassLoader(EgovWebServiceClassLoader classLoader) {
        this.classLoader = classLoader;
    }

    /**
     * applicationContext
     *
     * @param applicationContext the applicationContext to set
     */
    public void setApplicationContext(ApplicationContext applicationContext) {
        this.applicationContext = applicationContext;
    }

    /**
     * EgovWebServiceContext를 초기화한다.
     *
     * @throws IllegalArgumentException 필요한 attribute가 설정되어 있지 않을 경우
     */
    public void init() throws IllegalArgumentException {
        LOGGER.debug("### EgovWebServiceContext init() Start ");

        if (!StringUtils.hasText(organizationId)) {
            LOGGER.debug("### EgovWebServiceContext init() Argument 'organizationId' is null or has no text "
                    + "(organizationId = " + (organizationId == null ? "\"" : "") + organizationId + (organizationId == null ? "\"" : "") + ")");
            throw new IllegalArgumentException();
        } else if (!StringUtils.hasText(systemId)) {
            LOGGER.debug("### EgovWebServiceContext init() Argument 'systemId' is null or has no text "
                    + "(systemId = "  + (systemId == null ? "\"" : "") + systemId + (systemId == null ? "\"" : "") + ")");
            throw new IllegalArgumentException();
        } else if (integrationDefinitionDao == null) {
            LOGGER.debug("### EgovWebServiceContext init() Argument 'integrationDefinitionDao' is null");
            throw new IllegalArgumentException();
        } else if (webServiceClientDefinitionDao == null) {
            LOGGER.debug("### EgovWebServiceContext init() Argument 'webServiceClientDefinitionDao' is null");
            throw new IllegalArgumentException();
        } else if (webServiceServerDefinitionDao == null) {
            LOGGER.debug("### EgovWebServiceContext init() Argument 'webServiceServerDefinitionDao' is null");
            throw new IllegalArgumentException();
        } else if (typeLoader == null) {
            LOGGER.debug("### EgovWebServiceContext init() Argument 'typeLoader' is null");
            throw new IllegalArgumentException();
        } else if (classLoader == null) {
            LOGGER.debug("### EgovWebServiceContext init() Argument 'classLoader' is null");
            throw new IllegalArgumentException();
        }
        LOGGER.debug("### EgovWebServiceContext init() Create MessageConverter");
        messageConverter = new MessageConverterImpl(classLoader);

        initServerInfo();

        initClient();
    }

    /**
     * 웹서비스 서버 정보를 생성한다.
     */
    protected void initServerInfo() {
        LOGGER.debug("### EgovWebServiceContext initServerInfo() Initialzise Server Info");

        List<WebServiceServerDefinition> webServiceServerDefinitions = new ArrayList<WebServiceServerDefinition>();
        List<IntegrationDefinition> integrationDefinitions = integrationDefinitionDao.getIntegrationDefinitionOfProvider(organizationId, systemId);

        LOGGER.debug("### EgovWebServiceContext initServerInfo() Scan IntegrationDefinitions");
        for (IntegrationDefinition integrationDefinition : integrationDefinitions) {
            LOGGER.debug("### EgovWebServiceContext initServerInfo() Create Service Info of IntegrationDefinition({})", integrationDefinition);

            if (integrationDefinition == null) {
                LOGGER.debug("### EgovWebServiceContext initServerInfo() IntegrationDefinition is null");
                continue;
            } else if (!integrationDefinition.isValid()) {
                LOGGER.debug("### EgovWebServiceContext initServerInfo()IntegrationDefinition is invalid");
                continue;
            } else if (!integrationDefinition.isUsing()) {
                LOGGER.debug("### EgovWebServiceContext initServerInfo()IntegrationDefinition({}) is not usable", integrationDefinition);
                continue;
            } else if (!integrationDefinition.getProvider().isUsing()) {
                LOGGER.debug("### EgovWebServiceContext initServerInfo()IntegrationDefinition({})'s provider service is not usable", integrationDefinition);
                continue;
            }

            WebServiceServerDefinition webServiceServerDefinition = webServiceServerDefinitionDao.getWebServiceServerDefinition(integrationDefinition.getProvider());

            if (webServiceServerDefinition == null) {
                LOGGER.debug("### EgovWebServiceContext initServerInfo() WebServiceServerDefinition of IntegrationDefinition({}) does not exist.", integrationDefinition);
                continue;
            } else if (!webServiceServerDefinition.isValid()) {
                LOGGER.debug("### EgovWebServiceContext initServerInfo() WebServiceServerDefinition of IntegrationDefinition({}) is invalid", integrationDefinition);
                continue;
            }

            if (!webServiceServerDefinitions.contains(webServiceServerDefinition)) {
                webServiceServerDefinitions.add(webServiceServerDefinition);
            }
        }

        // Method Refactoring
        createWebServiceServerModule(webServiceServerDefinitions);
    }

    private void createWebServiceServerModule(List<WebServiceServerDefinition> webServiceServerDefinitions) {
        LOGGER.debug("### EgovWebServiceContext createWebServiceServerModule() Create WebService Server Module");

        serverList = new ArrayList<ServerInfo>();

        for (WebServiceServerDefinition webServiceServerDefinition : webServiceServerDefinitions) {
            LOGGER.debug("### EgovWebServiceContext createWebServiceServerModule() webServiceServerDefinition = {}", webServiceServerDefinition);

            RecordType requestType = null;
            try {
                requestType = (RecordType) typeLoader.getType(webServiceServerDefinition.getServiceDefinition().getRequestMessageTypeId());
            } catch (NoSuchTypeException| CircularInheritanceException e) {
                LOGGER.debug("[{}] EgovWebServiceContext createWebServiceServerModule() RequestMessageType RecordType(id = \"{}\") has circular inheritance. {}",
                        e.getClass().getName(), webServiceServerDefinition.getServiceDefinition().getRequestMessageTypeId(), e.getMessage());
                continue;
            }
            LOGGER.debug("### EgovWebServiceContext createWebServiceServerModule() RequestMesageType : {}", requestType);

            RecordType responseType = null;
            try {
                responseType = (RecordType) typeLoader.getType(webServiceServerDefinition.getServiceDefinition().getResponseMessageTypeId());
            } catch (NoSuchTypeException | CircularInheritanceException e) {
                LOGGER.debug("[{}] EgovWebServiceContext createWebServiceServerModule() ResponseMessageType RecordType(id = \"{}\") has circular inheritance. {}",
                        e.getClass().getName(), webServiceServerDefinition.getServiceDefinition().getResponseMessageTypeId(), e.getMessage());
                continue;
            }
            LOGGER.debug("### EgovWebServiceContext createWebServiceServerModule() ResponseMessageType : {}", responseType);

            ServiceEndpointInfo serviceEndpointInfo = null;
            try {
                serviceEndpointInfo = new ServiceEndpointInfoImpl(webServiceServerDefinition, requestType, responseType);
            } catch (IllegalArgumentException e) {
                LOGGER.debug("[{}] EgovWebServiceContext createWebServiceServerModule() Cannot create ServiceEndpointInfoImpl {}",
                        e.getClass().getName(), e.getMessage());
                continue;
            }
            LOGGER.debug("### EgovWebServiceContext initServerInfo() ServiceEndpointInfo = {}", serviceEndpointInfo);

            Class<?> serviceImplClass = null;
            try {
                serviceImplClass = classLoader.loadClass(serviceEndpointInfo);
            } catch (ClassNotFoundException e) {
                LOGGER.debug("[{}] EgovWebServiceContext createWebServiceServerModule() Cannot load ServerEndpoint Class {}",
                        e.getClass().getName(), e.getMessage());
                continue;
            }
            LOGGER.debug("### EgovWebServiceContext initServerInfo() ServiceEndpoint Class = {}", serviceImplClass);

            Object serviceImpl = null;
            try {
                serviceImpl = serviceImplClass.newInstance();
            } catch (IllegalAccessException| InstantiationException e) {
                LOGGER.debug("[{}] EgovWebServiceContext createWebServiceServerModule() Cannot instantiate ServiceEndpoint {}",
                        e.getClass().getName(), e.getMessage());
                continue;
            }
            LOGGER.debug("### EgovWebServiceContext createWebServiceServerModule() ServiceEndpoint instance = {}", serviceImpl);

            EgovIntegrationServiceProvider provider = null;
            try {
                provider = (EgovIntegrationServiceProvider) applicationContext.getBean(webServiceServerDefinition.getServiceDefinition().getServiceProviderBeanId());
            } catch (BeansException e) {
                LOGGER.debug("[{}] EgovWebServiceContext createWebServiceServerModule() Cannot get providerBean(id = \"{}\") {}",
                        e.getClass().getName(), webServiceServerDefinition.getServiceDefinition().getServiceProviderBeanId(), e.getMessage());
                continue;
            }
            LOGGER.debug("### EgovWebServiceContext createWebServiceServerModule() EgovIntegrationServiceProvider = {}", provider);

            ServiceBridge serviceBridge = null;
            try {
                serviceBridge = new ServiceBridgeImpl(provider, serviceEndpointInfo, messageConverter);
            } catch (IllegalArgumentException e) {
                LOGGER.debug("[{}] EgovWebServiceContext createWebServiceServerModule() Cannot create ServiceBridge {}",
                        e.getClass().getName(), e.getMessage());
                continue;
            }
            LOGGER.debug("### EgovWebServiceContext createWebServiceServerModule() ServiceBridge : {}", serviceBridge);

            Field fieldServiceBridge = null;
            String fieldName = classLoader.getFieldNameOfServiceBridge();
            try {
                fieldServiceBridge = serviceImplClass.getField(fieldName);
            } catch (NoSuchFieldException e) {
                LOGGER.debug("[{}] EgovWebServiceContext createWebServiceServerModule() ServiceEndpoint does not have the field(name = \"{}\") {}",
                        e.getClass().getName(), fieldName, e.getMessage());
                continue;
            }

            try {
                fieldServiceBridge.set(serviceImpl, serviceBridge);
            } catch (IllegalAccessException | IllegalArgumentException | SecurityException e) {
                LOGGER.debug("[{}] EgovWebServiceContext createWebServiceServerModule() Cannot set ServiceBridge to provider {}",
                        e.getClass().getName(), e.getMessage());
                continue;
            }

            LOGGER.debug("### EgovWebServiceContext createWebServiceServerModule() Add new ServiceInfo");
            serverList.add(new ServerInfo(webServiceServerDefinition.getAddress(), serviceImpl));
        }

        LOGGER.debug("### EgovWebServiceContext createWebServiceServerModule() Finished Initializing Server Info");
    }

    protected void initClient() {
        LOGGER.debug("### EgovWebServiceContext initClient() Initialize Client Info");

        serviceMap = new HashMap<String, EgovWebService>();

        List<IntegrationDefinition> integrationDefinitions = integrationDefinitionDao.getIntegrationDefinitionOfConsumer(organizationId, systemId);

        for (IntegrationDefinition integrationDefinition : integrationDefinitions) {
            LOGGER.debug("### EgovWebServiceContext initClient() Create Client Info of IntegrationDefinition({})", integrationDefinition);

            if (integrationDefinition == null) {
                LOGGER.debug("### EgovWebServiceContext initClient() IntegrationDefinition is null");
                continue;
            } else if (!integrationDefinition.isValid()) {
                LOGGER.debug("### EgovWebServiceContext initClient() IntegrationDefinition is invalid");
                continue;
            } else if (!integrationDefinition.isUsing()) {
                LOGGER.debug("### EgovWebServiceContext initClient() IntegrationDefinition({}) is not usagble", integrationDefinition);
                continue;
            } else if (!integrationDefinition.getProvider().isUsing()) {
                LOGGER.debug("### EgovWebServiceContext initClient() IntegrationDefinition({})'s provider service is not usable", integrationDefinition);
                continue;
            }

            WebServiceClientDefinition webServiceClientDefinition = webServiceClientDefinitionDao.getWebServiceClientDefinition(integrationDefinition.getProvider());

            if (webServiceClientDefinition == null) {
                LOGGER.debug("### EgovWebServiceContext initClient() WebServiceClientDefinition of IntegrationDefinition({}) does not exist.", integrationDefinition);
                continue;
            } else if (!webServiceClientDefinition.isValid()) {
                LOGGER.debug("### EgovWebServiceContext initClient() WebServiceClientDefinition of IntegrationDefinition({}) is invalid", integrationDefinition);
                continue;
            }

            LOGGER.debug("### EgovWebServiceContext initClient() WebServiceClientDefinition = " + webServiceClientDefinition);

            RecordType requestType = null;
            try {
                requestType = (RecordType) typeLoader.getType(webServiceClientDefinition.getServiceDefinition().getRequestMessageTypeId());
            } catch (NoSuchTypeException | CircularInheritanceException e) {
                LOGGER.debug("[{}] EgovWebServiceContext initClient() RequestMessageType RecordType(id = \"{}\") has circular inheritance. {}",
                        e.getClass().getName(), webServiceClientDefinition.getServiceDefinition().getRequestMessageTypeId(), e.getMessage());
                continue;
            }
            LOGGER.debug("### EgovWebServiceContext initClient() RequestMesageType = {}", requestType);

            RecordType responseType = null;
            try {
                responseType = (RecordType) typeLoader.getType(webServiceClientDefinition.getServiceDefinition().getResponseMessageTypeId());
            } catch (NoSuchTypeException| CircularInheritanceException e) {
                LOGGER.debug("[{}] EgovWebServiceContext initClient() ResponseMessageType RecordType(id = \"{}\") has circular inheritance. {}",
                        e.getClass().getName(), webServiceClientDefinition.getServiceDefinition().getResponseMessageTypeId(), e);
                continue;
            }
            LOGGER.debug("### EgovWebServiceContext initClient() ResponseMessageType = {}", responseType);

            // ServiceEndpointInterface 정보를 생성한다.
            ServiceEndpointInterfaceInfo serviceEndpointInterfaceInfo = null;
            try {
                serviceEndpointInterfaceInfo = new ServiceEndpointInterfaceInfoImpl(webServiceClientDefinition, requestType, responseType);
            } catch (IllegalArgumentException e) {
                LOGGER.debug("[{}] EgovWebServiceContext initClient() Cannot create ServiceEndpointInterfaceInfo {}", e.getClass().getName(), e.getMessage());
                continue;
            }
            LOGGER.debug("### EgovWebServiceContext initClient() ServiceEndpointInterfaceInfo = {}", serviceEndpointInterfaceInfo);

            EgovWebServiceClient client = null;
            try {
                client = new EgovWebServiceClientImpl(classLoader, serviceEndpointInterfaceInfo, messageConverter);
            } catch (ClassNotFoundException| MalformedURLException| NoSuchMethodException| SecurityException e) {
                LOGGER.debug("[{}] EgovWebServiceContext initClient() Cannot create EgovWebServiceClient {}", e.getClass().getName(), e.getMessage());
                continue;
            }
            LOGGER.debug("### EgovWebServiceContext initClient() EgovWebServiceClient : {}", client);

            EgovWebService service = null;
            try {
                service = new EgovWebService(integrationDefinition.getId(), defaultTimeout, integrationDefinition, client);
            } catch (IllegalArgumentException e) {
                LOGGER.debug("[{}] EgovWebServiceContext initClient() Cannot create EgovWebService {}", e.getClass().getName(), e.getMessage());
                continue;
            }
            LOGGER.debug("### EgovWebServiceContext initClient() EgovWebService : {}", service);
            LOGGER.debug("### EgovWebServiceContext initClient() Add Client Info");
            serviceMap.put(integrationDefinition.getId(), service);
        }

        LOGGER.debug("### EgovWebServiceContext initClient() Finish initializing Client Info");
    }

    public void publishServer(Bus bus) {
        LOGGER.debug("### EgovWebServiceContext publishServer() Start ");

        this.bus = bus;
        BusFactory.setDefaultBus(bus);

        for (ServerInfo serverInfo : serverList) {
            LOGGER.debug("### EgovWebServiceContext publishServer() Publish Server (address = \"{}\")", serverInfo.address);
            try {
                Endpoint.publish(serverInfo.address, serverInfo.serviceImpl);
                //2017.02.15 장동한 시큐어코딩(ES)-부적절한 예외 처리[CWE-253, CWE-440, CWE-754]
            } catch (IllegalArgumentException e) {
                LOGGER.debug("[{}] EgovWebServiceContext publishServer() Fail in publishing Server (address = \"{}\") {}",
                        e.getClass().getName(), serverInfo.address, e.getMessage());
            }
        }

        LOGGER.debug("### EgovWebServiceContext publishServer() Finish publish Server");
    }

    public void attachMonitor(EgovIntegrationServiceMonitor monitor) {
    }

    public void detachMonitor(EgovIntegrationServiceMonitor monitor) {
    }

    public EgovIntegrationService getService(String id) {
        if (!serviceMap.containsKey(id)) {
            throw new EgovIntegrationNoSuchServiceException();
        }
        return serviceMap.get(id);
    }

    protected static class ServerInfo {
        private String address;
        private Object serviceImpl;

        public ServerInfo(String address, Object serviceImpl) {
            super();
            this.address = address;
            this.serviceImpl = serviceImpl;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public Object getServiceImpl() {
            return serviceImpl;
        }

        public void setServiceImpl(Object serviceImpl) {
            this.serviceImpl = serviceImpl;
        }
    }

}
