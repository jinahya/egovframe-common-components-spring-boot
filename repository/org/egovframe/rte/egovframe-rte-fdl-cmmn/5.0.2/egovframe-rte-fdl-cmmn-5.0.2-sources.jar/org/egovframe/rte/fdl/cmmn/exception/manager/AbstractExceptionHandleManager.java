/*
 * Copyright 2008-2024 MOIS(Ministry of the Interior and Safety).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.egovframe.rte.fdl.cmmn.exception.manager;

import jakarta.annotation.Resource;
import org.egovframe.rte.fdl.cmmn.exception.handler.ExceptionHandler;
import org.springframework.context.MessageSource;
import org.springframework.util.PathMatcher;

/**
 * AbstractExceptionHandleManager
 * 사용자 ExceptionHandleManager 구현시 상속되는 추상클래스이다.
 * ExceptionHandlerService 인터페이스의 메소드를 거의 다 구현해 놓은 추상클래스이기 때문에 사용자가 구현시
 * run(Exception exception) 만 구현을 해주면 된다.
 * 실행환경은 {@code ExceptionHandlerService#run(Exception, String)} 으로 호출하므로, 싱글톤 빈의 상태 변경 없이
 * 처리하려면 그 메소드를 재정의한다.
 *
 * @author Judd Cho (horanghi@gmail.com)
 * @version 1.0
 * <pre>
 * 개정이력(Modification Information)
 *
 * 수정일		수정자				수정내용
 * ----------------------------------------------
 * 2009.05.30	Judd Cho			최초 생성
 * 2015.01.31	Vincent Han			코드 품질 개선
 * 2026.09.10	실행환경 개발팀		싱글톤 상태 변경 방식(setPackageName·run(Exception)) deprecated
 * </pre>
 * @since 2009.06.01
 */
public abstract class AbstractExceptionHandleManager {

    @Resource(name = "messageSource")
    protected MessageSource messageSource;

    protected Exception ex;
    protected String thisPackageName;
    protected String[] patterns;
    protected ExceptionHandler[] handlers;
    protected PathMatcher pm;

    /**
     * setPatterns 메소드.
     * 패키지, 클래스 이름으로 패턴등록(Ant형식의 매칭)
     *
     * @param patterns 패턴리스트
     */
    public void setPatterns(String[] patterns) {
        this.patterns = patterns;
    }

    /**
     * setHandlers 메소드.
     * ExceptionHandler 리스트 등록
     *
     * @param handlers handler리스트
     */
    public void setHandlers(ExceptionHandler[] handlers) {
        this.handlers = handlers;
    }

    /**
     * getPackagename 메소드.
     *
     * @return packageName
     */
    public String getPackageName() {
        return this.thisPackageName;
    }

    /**
     * setPackageName 메소드.
     * 비교할 클래스 정보
     *
     * @param canonicalName 비교할 클래스명
     * @deprecated 싱글톤 빈의 필드를 요청마다 바꾸는 방식이라 동시 요청에서 다른 호출의
     * 발생 위치로 매칭될 수 있다. {@code ExceptionHandlerService#run(Exception, String)} 으로 발생 위치를 직접 전달한다.
     */
    @Deprecated
    public void setPackageName(String canonicalName) {
        this.thisPackageName = canonicalName;
    }

    /**
     * setException 메소드.
     *
     * @param be Exception
     */
    public void setException(Exception be) {
        this.ex = be;
    }

    /**
     * setReqExpMatcher 메소드.
     *
     * @param pm 별도의 PathMatcher
     */
    public void setReqExpMatcher(PathMatcher pm) {
        this.pm = pm;
    }

    /**
     * PathMatcher 가 있는지 여부 반환.
     *
     * @return boolean true|false
     */
    public boolean hasReqExpMatcher() {
        return this.enableMatcher();
    }

    /**
     * PathMatcher 가 있는지 여부 반환.
     *
     * @return boolean true|false
     */
    public boolean enableMatcher() {
        return (this.pm == null) ? false : true;
    }

    /**
     * 상속받아 구현해야할 메스드 하지만 미리구현은 먼저 해둠. 실 구현체에서 override 하여 구현해야 함.
     *
     * @param exception 발생한 Exception
     * @return boolean 실행성공여부
     * @deprecated {@link #setPackageName(String)} 으로 미리 넣어 둔 필드에 의존하므로 동시 요청에서
     * 오동작할 수 있다. {@code ExceptionHandlerService#run(Exception, String)} 으로 대체한다.
     */
    @Deprecated
    public boolean run(Exception exception) throws Exception {
        if (!enableMatcher()) {
            return false;
        }
        for (String pattern : patterns) {
            if (pm.match(pattern, thisPackageName)) {
                for (ExceptionHandler eh : handlers) {
                    eh.occur(exception, getPackageName());
                }
                break;
            }
        }
        return true;
    }

}
