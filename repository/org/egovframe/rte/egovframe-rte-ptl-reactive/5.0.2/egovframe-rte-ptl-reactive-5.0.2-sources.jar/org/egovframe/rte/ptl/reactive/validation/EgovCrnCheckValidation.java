/*
 * Copyright 2008-2024 MOIS(Ministry of the Interior and Safety).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.egovframe.rte.ptl.reactive.validation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 사업자등록번호 유효성을 검증하기 위한 클래스
 *
 * <p>Desc.: 사업자등록번호 유효성을 검증하기 위한 클래스</p>
 *
 * @author 유지보수
 * @version 1.0
 * <pre>
 * 개정이력(Modification Information)
 *
 * 수정일		수정자				수정내용
 * ----------------------------------------------
 * 2023.08.31   유지보수            최초 생성
 * </pre>
 * @since 2023.08.31
 */
public class EgovCrnCheckValidation implements ConstraintValidator<EgovCrnCheck, String> {

    private static final Pattern CRN_PATTERN = Pattern.compile("^[\\d]{10}+$");

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (value == null) {
            return false;
        }
        String mValue = value.replaceAll("-", "");
        Matcher matcher = CRN_PATTERN.matcher(mValue);
        boolean check = matcher.matches();
        if (!check) {
            return false;
        }

        int sum = 0;
        int[] weightArray = {1, 3, 7, 1, 3, 7, 1, 3, 5};
        for (int i = 0; i < weightArray.length; i++) {
            sum += weightArray[i] * Integer.parseInt(mValue.substring(i, i + 1));
        }
        sum += Integer.parseInt(mValue.substring(8, 9)) * 5 / 10;
        int total = (10 - sum % 10) % 10;
        return total == Integer.parseInt(mValue.substring(9));
    }

}
