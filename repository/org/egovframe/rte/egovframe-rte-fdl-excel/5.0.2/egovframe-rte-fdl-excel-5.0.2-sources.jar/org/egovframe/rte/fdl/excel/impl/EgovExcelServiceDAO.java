/*
 * Copyright 2008-2024 MOIS(Ministry of the Interior and Safety).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.egovframe.rte.fdl.excel.impl;

import com.ibatis.sqlmap.client.SqlMapClient;
import org.egovframe.rte.psl.orm.ibatis.SqlMapClientCallback;
import org.egovframe.rte.psl.orm.ibatis.support.SqlMapClientDaoSupport;

import java.util.List;

/**
 * 엑셀서비스을 처리하는 DAO 클래스.
 * <p>
 * 개정이력(Modification Information)
 * <p>
 * 수정일		수정자				수정내용
 * ----------------------------------------------
 * 2009.06.01   윤성종             최초 생성
 */
@SuppressWarnings("deprecation")
public class EgovExcelServiceDAO extends SqlMapClientDaoSupport {

    @SuppressWarnings("unused")
    private SqlMapClient sqlMapClient;

    public EgovExcelServiceDAO(SqlMapClient sqlMapClient) {
        this.sqlMapClient = sqlMapClient;
        super.setSqlMapClient(sqlMapClient);
    }

    /**
     * 엑셀서비스의 배치업로드를 실행한다.
     */
    public Integer batchInsert(final String queryId, final List<Object> list) {
        return (Integer) getSqlMapClientTemplate().execute(
                (SqlMapClientCallback<Object>) executor -> {
                    executor.startBatch();
                    for (Object o : list) {
                        executor.insert(queryId, o);
                    }
                    return executor.executeBatch();
                });
    }

    /**
     * 엑셀서비스의 배치업로드를 실행한다.
     * 업로드할 엑셀의 시작 위치를 정하여 지정한 셀부터 업로드한다.
     */
    public Integer batchInsert(final String queryId, final List<Object> list, final int start) {
        return (Integer) getSqlMapClientTemplate().execute(
                (SqlMapClientCallback<Object>) executor -> {
                    executor.startBatch();
                    int size = list.size();
                    for (int i = start; i < size; i++) {
                        executor.insert(queryId, list.get(i));
                    }
                    return executor.executeBatch();
                });
    }

}
