/*
 * Copyright 2008-2024 MOIS(Ministry of the Interior and Safety).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.egovframe.rte.bat.core.reflection;

import org.apache.commons.lang3.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Reflection 관련 method
 *
 * @author 실행환경 개발팀
 * @version 1.0
 * <pre>
 * 개정이력(Modification Information)
 *
 * 수정일		수정자				수정내용
 * ----------------------------------------------
 * 2012.07.20	실행환경개발팀		최초 생성
 * 2017.02.15	장동한				시큐어코딩(ES)-부적절한 예외 처리[CWE-253, CWE-440, CWE-754]
 * </pre>
 * @since 2012.07.20
 */
public class EgovReflectionSupport<T> {

    private static final Logger LOGGER = LoggerFactory.getLogger(EgovReflectionSupport.class);

    private Object object = null;
    private volatile Method[] methods;
    private volatile HashMap<String, Method> methodMap;
    private Type[] fieldType;

    public EgovReflectionSupport() {
        super();
    }

    /**
     * VO에 들어있는 Method 목록 get
     */
    public HashMap<String, Method> getMethodMap() {
        return methodMap;
    }

    /**
     * 주어진 Method 이름(methodName)으로  Method를 검색한다.
     *
     * @param methods
     * @param methodName
     * @return Method
     */
    private Method retrieveMethod(Method[] methods, String methodName) {
        Method method = null;
        for (int i = 0; i < methods.length; i++) {
            if (methods[i].getName().equals(methodName)) {
                method = methods[i];
                break;
            }
        }
        return method;
    }

    private Method retrieveGetterMethod(Method[] methods, String methodName) {
        for (Method method : methods) {
            if (method.getName().equals(methodName) && method.getParameterCount() == 0) {
                return method;
            }
        }
        return null;
    }

    /**
     * VO 타입의 instance 생성
     *
     * @param type VO 타입
     */
    private void createObject(Class<?> type) {
        try {
            object = type.newInstance();
        } catch (InstantiationException | IllegalAccessException e) {
            ReflectionUtils.handleReflectionException(e);
        }
    }

    /**
     * VO의 Field명과 Setter Method들을 비교하여 Map에 Put 한다.
     * Bean 생성시 한 번만 실행 된다.
     */
    public void generateSetterMethodMap(Class<?> type, String[] names) {
        try {
            methods = type.newInstance().getClass().getMethods();
        } catch (InstantiationException | IllegalAccessException e) {
            ReflectionUtils.handleReflectionException(e);
        }
        methodMap = new HashMap<String, Method>();
        try {
            if (ArrayUtils.isNotEmpty(names) && names.length > 0) {
                for (int i = 0; i < names.length; i++) {
                    String strMethod;
                    if (names[i].length() > 0) {
                        strMethod = "set" + (names[i].substring(0, 1)).toUpperCase(Locale.ROOT) + names[i].substring(1);
                        methodMap.put(names[i], retrieveMethod(methods, strMethod));
                    }
                }
            }
            //2017.02.15 장동한 시큐어코딩(ES)-부적절한 예외 처리[CWE-253, CWE-440, CWE-754]
        } catch (StringIndexOutOfBoundsException | NullPointerException e) {
            ReflectionUtils.handleReflectionException(e);
        }
    }

    /**
     * VO의 Setter method 실행
     *
     * @param tokens VO에 set 될 value
     * @param names  VO의 field 명
     */
    private void invokeSetterMethod(List<String> tokens, String[] names) {
        Method method;
        for (int i = 0; i < names.length; i++) {
            method = methodMap.get(names[i]);
            try {
                method.invoke(object, parsingFromString(tokens.get(i).trim(), fieldType[i]));
            } catch (IllegalAccessException | InvocationTargetException e) {
                ReflectionUtils.handleReflectionException(e);
            }
        }
    }

    @SuppressWarnings("unchecked")
    public T generateObject(Class<?> type, List<String> tokens, String[] names) {
        createObject(type);
        invokeSetterMethod(tokens, names);
        return (T) object;
    }

    /**
     * VO의 Field명과 Getter Method들을 비교하여 Map에 Put 한다.
     * Bean 생성시 한 번만 실행 된다.
     */
    public void generateGetterMethodMap(String[] names, T item) {
        // 멀티스레드 step에서 FieldExtractor/ItemWriter 빈이 공유되면 이 인스턴스도 공유된다.
        // 기존 코드는 methods를 먼저 대입한 뒤 methodMap을 채워, 다른 스레드가 methods != null 만 보고
        // 아직 채워지지 않은(또는 null인) methodMap을 사용하다 NPE/부분초기화에 노출되었다.
        // double-checked locking + 지역변수로 완성한 뒤 발행하여 부분초기화 상태가 외부에 보이지 않게 한다.
        if (methods != null) {
            return;
        }
        synchronized (this) {
            if (methods != null) {
                return;
            }
            Method[] localMethods = item.getClass().getMethods();
            HashMap<String, Method> localMap = new HashMap<String, Method>();
            try {
                if (ArrayUtils.isNotEmpty(names) && names.length > 0) {
                    for (int i = 0; i < names.length; i++) {
                        if (names[i].length() > 0) {
                            String suffix = names[i].substring(0, 1).toUpperCase(Locale.ROOT) + names[i].substring(1);
                            // 기존 getXxx 선택을 유지하고, 없으면 boolean isXxx를 사용한다.
                            Method getter = retrieveGetterMethod(localMethods, "get" + suffix);
                            if (getter == null) {
                                Method booleanGetter = retrieveGetterMethod(localMethods, "is" + suffix);
                                if (booleanGetter != null && booleanGetter.getReturnType() == boolean.class) {
                                    getter = booleanGetter;
                                }
                            }
                            localMap.put(names[i], getter);
                        }
                    }
                }
                //2017.02.15 장동한 시큐어코딩(ES)-부적절한 예외 처리[CWE-253, CWE-440, CWE-754]
            } catch (StringIndexOutOfBoundsException | NullPointerException e) {
                ReflectionUtils.handleReflectionException(e);
            }
            // 완성된 map을 먼저 발행한 뒤 methods를 마지막에 대입(초기화 완료 표식)한다.
            methodMap = localMap;
            methods = localMethods;
        }
    }

    /**
     * item의 field 정보를 가져오기 위해 getter를 invoke
     *
     * @param item  정보를 담고 있는 VO
     * @param names VO의 field name
     * @return getValue field 정보를 get 하여 return
     */
    public Object invokeGettterMethod(T item, String names) {
        Object value = null;
        try {
            value = methodMap.get(names).invoke(item);
        } catch (IllegalArgumentException | IllegalAccessException | InvocationTargetException e) {
            ReflectionUtils.handleReflectionException(e);
        }
        return value;
    }

    /**
     * item의 field 정보를 가져오기 위해 getter를 invoke
     *
     * @param item      item 정보를 담고 있는 VO
     * @param param
     * @param mapMethod VO의 getter 메소드를 갖고 있는 Map
     * @return field 정보를 get 하여 return
     */
    public Object invokeGettterMethod(T item, String param, Map<String, Method> mapMethod) {
        Object value = null;
        try {
            value = mapMethod.get(param).invoke(item);
        } catch (IllegalArgumentException | IllegalAccessException | InvocationTargetException e) {
            ReflectionUtils.handleReflectionException(e);
        }
        return value;
    }

    /**
     * VO의 field의 타입 get
     *
     * @param type  VO의 타입
     * @param names VO field names
     */
    public void getFieldType(Class<?> type, String[] names) {
        fieldType = new Type[names.length];
        for (int i = 0; i < names.length; i++) {
            try {
                fieldType[i] = type.newInstance().getClass().getDeclaredField(names[i]).getType();
            } catch (SecurityException | NoSuchFieldException | InstantiationException | IllegalAccessException e) {
                ReflectionUtils.handleReflectionException(e);
            }
        }
    }

    /**
     * sqlType을 배열 형식으로 받는 메소드
     */
    public String[] getSqlTypeArray(String[] params, Object item) {
        String[] sqlTypes = new String[params.length];
        for (int i = 0; i < params.length; i++) {
            try {
                sqlTypes[i] = item.getClass().getDeclaredField(params[i]).getType().getSimpleName().toString();
            } catch (SecurityException | NoSuchFieldException e) {
                ReflectionUtils.handleReflectionException(e);
            }
        }
        return sqlTypes;
    }

    /**
     * String to Type parsing
     *
     * @param tokenValue String 형태의 token value
     * @param type       실제 VO에서 token value의 type
     * @return parsingValue 해당 type으로 paring한 value return
     */
    private Object parsingFromString(String tokenValue, Type type) {
        Object parsingValue = null;
        if (type == String.class) {
            parsingValue = tokenValue;
        } else if (type == int.class || type == Integer.class) {
            parsingValue = Integer.parseInt(tokenValue);
        } else if (type == double.class || type == Double.class) {
            parsingValue = Double.parseDouble(tokenValue);
        } else if (type == float.class || type == Float.class) {
            parsingValue = Float.parseFloat(tokenValue);
        } else if (type == long.class || type == Long.class) {
            parsingValue = Long.parseLong(tokenValue);
        } else if (type == char.class || type == Character.class) {
            parsingValue = tokenValue.charAt(0);
        } else if (type == byte[].class) {
            parsingValue = tokenValue.getBytes();
        } else if (type == boolean.class || type == Boolean.class) {
            parsingValue = Boolean.valueOf(tokenValue);
        } else if (type == BigDecimal.class) {
            parsingValue = new BigDecimal(tokenValue);
        } else {
            parsingValue = tokenValue;
        }
        return parsingValue;
    }

}
