/*
 * Copyright 2008-2024 MOIS(Ministry of the Interior and Safety).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.egovframe.rte.itl.integration.metadata;

import org.egovframe.rte.itl.integration.util.Validatable;
import org.springframework.util.StringUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 연계 서비스 메타 데이터 중 '기관' 구현 클래스
 * <p>
 * <b>NOTE:</b> 전자정부 연계 서비스 메타 데이터 중 '기관'를 나타내는 class이다.
 * </p>
 *
 * @author 실행환경 개발팀 심상호
 * @version 1.0
 * <pre>
 * 개정이력(Modification Information)
 *
 * 수정일		수정자				수정내용
 * ----------------------------------------------
 * 2009.06.01	심상호				최초 생성
 * </pre>
 * @since 2009.06.01
 */
public class OrganizationDefinition implements Validatable {

    /**
     * 기관 ID
     */
    private String id;

    /**
     * 기관명
     */
    private String name;

    /**
     * 소속 시스템
     */
    private Map<String, SystemDefinition> systems = new HashMap<String, SystemDefinition>();

    /**
     * valid
     */
    private boolean valid = false;

    /**
     * statucChanged flag
     */
    private AtomicBoolean statusChanged = new AtomicBoolean(false);

    /**
     * Default Constructor
     */
    public OrganizationDefinition() {
        super();
    }

    /**
     * Constructor
     *
     * @param id   기관 ID
     * @param name 기관명
     */
    public OrganizationDefinition(String id, String name) {
        super();
        this.id = id;
        this.name = name;
        this.statusChanged.set(true);
    }

    /**
     * Constructor
     *
     * @param id      기관 ID
     * @param name    기관명
     * @param systems 소속 시스템
     */
    public OrganizationDefinition(String id, String name,
                                  Map<String, SystemDefinition> systems) {
        super();
        this.id = id;
        this.name = name;
        this.systems = systems;
        this.statusChanged.set(true);
    }

    /**
     * 기관 ID
     *
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * 기관 ID
     *
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
        this.statusChanged.set(true);
    }

    /**
     * 기관명
     *
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * 기관명
     *
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
        this.statusChanged.set(true);
    }

    /**
     * 소속시스템
     *
     * @return the systems
     */
    public Map<String, SystemDefinition> getSystems() {
        return systems;
    }

    /**
     * 소속시스템
     *
     * @param systems the systems to set
     */
    public void setSystems(Map<String, SystemDefinition> systems) {
        this.systems = systems;
        this.statusChanged.set(true);
    }

    /**
     * SystemDefinition을 읽어온다.
     *
     * @param systemId systemId
     * @return SystemDefinition
     */
    public SystemDefinition getSystemDefinition(String systemId) {
        return systems.get(systemId);
    }

    public boolean isValid() {
        if (statusChanged.getAndSet(false)) {
            valid = (StringUtils.hasText(id) && StringUtils.hasText(name) && systems != null);
            if (systems != null) {
                for (SystemDefinition system : systems.values()) {
                    valid = valid && system.isValid();
                }
            }
        }
        return valid;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.getClass().getName()).append(" {").append("\n\tid = ")
                .append(StringUtils.quote(id)).append("\n\tname = ")
                .append(StringUtils.quote(name))
                .append("\n\tsystems = ").append(systems == null ? "null" : "[...]");
        sb.append("\n}");
        return sb.toString();
    }

}
