/*
 * Copyright 2008-2024 MOIS(Ministry of the Interior and Safety).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.egovframe.rte.ptl.mvc.tags.ui.pagination;

import java.text.MessageFormat;

/**
 * AbstractPaginationRenderer.java
 * <p/><b>NOTE:</b><pre> 인터페이스 PaginationRenderer의 구현 추상클래스.
 * 기본적인 페이징 기능이 구현되어 있으며, 화면에서 아래와 같이 display 된다.
 *
 * [처음][이전] 1 2 3 4 5 6 7 8 [다음][마지막]
 *
 * 클래스 변수들이 각 element와 매핑이 되는데,
 * firstPageLabel = [처음]
 * previousPageLabel = [이전]
 * currentPageLabel = 현재 페이지 번호
 * otherPageLabel = 현재 페이지를 제외한 페이지 번호
 * nextPageLabel = [다음]
 * lastPageLabel = [마지막]
 *
 * 클래스 변수값을 AbstractPaginationRenderer를 상속받은 하위 클래스에서 주게 되면,
 * 페이징 포맷만 프로젝트 UI에 맞춰 커스터마이징 할 수 있다.
 * 자세한 사항은 개발자 메뉴얼의 개발프레임워크 실행환경/화면처리/MVC/View/Pagination Tag를 참고하라.
 * </pre>
 *
 * @author 실행환경 개발팀 함철
 * @version 1.0
 * <pre>
 * 개정이력(Modification Information)
 *
 * 수정일		수정자				수정내용
 * ----------------------------------------------
 * 2009.05.30	함철				최초 생성
 * 2026.09.10	실행환경 개발팀		라벨 setter 와 라벨 파라미터형 doRender() 추가(로케일별 라벨 렌더러 지원)
 * </pre>
 * @since 2009.06.01
 */
public abstract class AbstractPaginationRenderer implements PaginationRenderer {

    protected String firstPageLabel;
    protected String previousPageLabel;
    protected String currentPageLabel;
    protected String otherPageLabel;
    protected String nextPageLabel;
    protected String lastPageLabel;

    public void setFirstPageLabel(String firstPageLabel) {
        this.firstPageLabel = firstPageLabel;
    }

    public void setPreviousPageLabel(String previousPageLabel) {
        this.previousPageLabel = previousPageLabel;
    }

    public void setCurrentPageLabel(String currentPageLabel) {
        this.currentPageLabel = currentPageLabel;
    }

    public void setOtherPageLabel(String otherPageLabel) {
        this.otherPageLabel = otherPageLabel;
    }

    public void setNextPageLabel(String nextPageLabel) {
        this.nextPageLabel = nextPageLabel;
    }

    public void setLastPageLabel(String lastPageLabel) {
        this.lastPageLabel = lastPageLabel;
    }

    public String renderPagination(PaginationInfo paginationInfo, String jsFunction) {
        return doRender(paginationInfo, jsFunction,
                firstPageLabel, previousPageLabel, currentPageLabel, otherPageLabel, nextPageLabel, lastPageLabel);
    }

    /**
     * 라벨 템플릿을 파라미터로 받아 렌더링한다.
     * 요청 로케일(Locale)마다 라벨이 달라지는 렌더러가 공유 필드를 바꾸지 않고(스레드 안전) 재사용하는 렌더링 지점이다.
     */
    protected String doRender(PaginationInfo paginationInfo, String jsFunction,
            String firstPageLabel, String previousPageLabel, String currentPageLabel,
            String otherPageLabel, String nextPageLabel, String lastPageLabel) {

        StringBuilder stringBuilder = new StringBuilder();

        int firstPageNo = paginationInfo.getFirstPageNo();
        int firstPageNoOnPageList = paginationInfo.getFirstPageNoOnPageList();
        int totalPageCount = paginationInfo.getTotalPageCount();
        int pageSize = paginationInfo.getPageSize();
        int lastPageNoOnPageList = paginationInfo.getLastPageNoOnPageList();
        int currentPageNo = paginationInfo.getCurrentPageNo();
        int lastPageNo = paginationInfo.getLastPageNo();

        if (totalPageCount > pageSize) {
            if (firstPageNoOnPageList > pageSize) {
                stringBuilder.append(MessageFormat.format(firstPageLabel, new Object[]{jsFunction, Integer.toString(firstPageNo)}));
                stringBuilder.append(MessageFormat.format(previousPageLabel, new Object[]{jsFunction, Integer.toString(firstPageNoOnPageList - 1)}));
            } else {
                stringBuilder.append(MessageFormat.format(firstPageLabel, new Object[]{jsFunction, Integer.toString(firstPageNo)}));
                stringBuilder.append(MessageFormat.format(previousPageLabel, new Object[]{jsFunction, Integer.toString(firstPageNo)}));
            }
        }

        for (int i = firstPageNoOnPageList; i <= lastPageNoOnPageList; i++) {
            if (i == currentPageNo) {
                stringBuilder.append(MessageFormat.format(currentPageLabel, new Object[]{Integer.toString(i)}));
            } else {
                stringBuilder.append(MessageFormat.format(otherPageLabel, new Object[]{jsFunction, Integer.toString(i), Integer.toString(i)}));
            }
        }

        if (totalPageCount > pageSize) {
            if (lastPageNoOnPageList < totalPageCount) {
                stringBuilder.append(MessageFormat.format(nextPageLabel, new Object[]{jsFunction, Integer.toString(firstPageNoOnPageList + pageSize)}));
                stringBuilder.append(MessageFormat.format(lastPageLabel, new Object[]{jsFunction, Integer.toString(lastPageNo)}));
            } else {
                stringBuilder.append(MessageFormat.format(nextPageLabel, new Object[]{jsFunction, Integer.toString(lastPageNo)}));
                stringBuilder.append(MessageFormat.format(lastPageLabel, new Object[]{jsFunction, Integer.toString(lastPageNo)}));
            }
        }
        return stringBuilder.toString();
    }

}
